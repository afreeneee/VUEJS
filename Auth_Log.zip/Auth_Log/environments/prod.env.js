module.exports = {
  NODE_ENV: '"production"',
  BASE_URL: '"http://192.168.12.29:8080"',
  TOKEN_NAME: '"zoylo_frontuser_prod_token"',
  DEBUG: false
}
