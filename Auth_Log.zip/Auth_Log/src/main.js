import Vue from 'vue/dist/vue.js'
// import axios from 'axios';
import BootstrapVue from 'bootstrap-vue';
import VeeValidate from 'vee-validate';
import VueContentPlaceholders from 'vue-content-placeholders';
import middleware from './app/services/middleware';
import VueHead from 'vue-head';
import { App } from './app';
import router from './router';
import store from './store';
import GlobalComponents from './app/components/common/globalComponents/index';
import './app/services/http';
import './app/services/auth';



Vue.use(GlobalComponents);
Vue.use(BootstrapVue);
Vue.use(VeeValidate);
Vue.use(VueContentPlaceholders, {
});

Vue.use(VueHead);

const eventBus = new Vue();

Vue.mixin({
  data() {
    return {
      eventBus,
    };
  },
});
middleware(router);
/* eslint-disable no-new */
new Vue({
  el: '#app',
  router,
  store,
  template: '<App/>',
  components: { App },
});

