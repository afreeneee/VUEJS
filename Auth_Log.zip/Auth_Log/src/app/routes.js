import { routes as Landing } from './components/recipient';
import { routes as Auth } from './components/auth';
import { routes as CommonUI } from './components/common/globalComponents';


export default [...Landing,...Auth,...CommonUI]; //eslint-disable-line
