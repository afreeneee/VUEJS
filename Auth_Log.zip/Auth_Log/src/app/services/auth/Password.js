// const sha256 = require('js-sha256').sha256;

const encode = function encode(password) {
  return password; // sha256(password);
};

export default {
  encode,
};
