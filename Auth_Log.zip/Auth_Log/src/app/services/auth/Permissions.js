const permissions = {
  DOCTOR_CLINIC: {
    PERMISSIONS: {
      DOC_DASHBOARD_VIEW: {
        PERMISSION_CODE: 'DOC_DASHBOARD_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View Dashboard',
      },
      DOC_ADD_NEW_APPOINTMENT: {
        PERMISSION_CODE: 'DOC_ADD_NEW_APPOINTMENT',
        PERMISSION_NAME: 'Doctor Clinic - Add Add Appointment',
      },
      DOC_MY_APPOINTMENTS_VIEW: {
        PERMISSION_CODE: 'DOC_MY_APPOINTMENTS_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View Appointment',
      },
      DOC_CLINIC_GALLERY_ADD: {
        PERMISSION_CODE: 'DOC_CLINIC_GALLERY_ADD',
        PERMISSION_NAME: 'Doctor Clinic - Add Clinic Gallery',

      },
      DOC_FACILITIES_ADD: {
        PERMISSION_CODE: 'DOC_FACILITIES_ADD',
        PERMISSION_NAME: 'Doctor Clinic - Add Facilities',
      },
      DOC_FACILITIES_VIEW: {
        PERMISSION_CODE: 'DOC_FACILITIES_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View Facilities',
      },
      DOC_ABOUT_CLINIC_VIEW: {
        PERMISSION_CODE: 'DOC_ABOUT_CLINIC_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View About Clinic',
      },
      DOC_ABOUT_CLINIC_ADD: {
        PERMISSION_CODE: 'DOC_ABOUT_CLINIC_ADD',
        PERMISSION_NAME: 'Doctor Clinic - Add About Clinic',
      },
      DOC_MY_PATIENTS_VIEW: {
        PERMISSION_CODE: 'DOC_MY_PATIENTS_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View My Patients',
      },
      DOC_USER_SETTINGS_VIEW: {
        PERMISSION_CODE: 'DOC_USER_SETTINGS_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View User Settings',
      },
      DOC_USER_SETTINGS_ADD: {
        PERMISSION_CODE: 'DOC_USER_SETTINGS_ADD',
        PERMISSION_NAME: 'Doctor Clinic - Add User Settings',
      },
      DOC_REPORTS_VIEW: {
        PERMISSION_CODE: 'DOC_REPORTS_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View Reports',
      },
      DOC_CLINIC_REPORTS_VIEW: {
        PERMISSION_CODE: 'DOC_CLINIC_REPORTS_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - Add Reports',
      },
      DOC_CLINIC_REPORTS_MANAGE: {
        PERMISSION_CODE: 'DOC_CLINIC_REPORTS_MANAGE',
        PERMISSION_NAME: 'Doctor Clinic - Export Reports',
      },
      DOC_SERVICES_VIEW: {
        PERMISSION_CODE: 'DOC_SERVICES_VIEW',
        PERMISSION_NAME: 'Doctor Clinic - View Services',
      },
      DOC_MY_PROFILE_VIEW: {
        PERMISSION_CODE: 'DOC_MY_PROFILE_VIEW',
        PERMISSION_NAME: 'Doctor Profile - View Profile',
      },
      DOC_MY_PROFILE_MANAGE: {
        PERMISSION_CODE: 'DOC_MY_PROFILE_MANAGE',
        PERMISSION_NAME: 'Doctor Profile - Manage Profile',
      },
      DOC_MY_SCHEDULE_VIEW: {
        PERMISSION_CODE: 'DOC_MY_SCHEDULE_VIEW',
        PERMISSION_NAME: 'Doctor Schedule - View Doctor Schedule',
      },
      DOC_MY_SCHEDULE_MANAGE: {
        PERMISSION_CODE: 'DOC_MY_SCHEDULE_MANAGE',
        PERMISSION_NAME: 'Doctor Schedule - Manage Doctor Schedule',
      },
      DOC_MY_FEES_VIEW: {
        PERMISSION_CODE: 'DOC_MY_FEES_VIEW',
        PERMISSION_NAME: 'Doctor Schedule - View Doctor Fee',
      },
      DOC_MY_FEES_MANAGE: {
        PERMISSION_CODE: 'DOC_MY_FEES_MANAGE',
        PERMISSION_NAME: 'Doctor Schedule - Manage Doctor Fee',
      },
      DOC_MY_NOTIFICATIONS_VIEW: {
        PERMISSION_CODE: 'DOC_MY_NOTIFICATIONS_VIEW',
        PERMISSION_NAME: 'Doctor Schedule - View Notifications',
      },
      DOC_MY_NOTIFICATIONS_MANAGE: {
        PERMISSION_CODE: 'DOC_MY_NOTIFICATIONS_MANAGE',
        PERMISSION_NAME: 'Doctor Schedule - Manage Notifications',
      },
      DOC_MY_PATIENTS_MANAGE: {
        PERMISSION_CODE: 'DOC_MY_PATIENTS_MANAGE',
        PERMISSION_NAME: 'Doctor - Manage Patient',
      },
      DOC_CLINIC_DETAIL_INFO_VIEW: {
        PERMISSION_CODE: 'DOC_CLINIC_DETAIL_INFO_VIEW',
        PERMISSION_NAME: 'Doctor - Doctor Clinic detail info view',
      },
      DOC_CLINIC_DETAIL_INFO_MANAGE: {
        PERMISSION_CODE: 'DOC_CLINIC_DETAIL_INFO_MANAGE',
        PERMISSION_NAME: 'Doctor - Doctor Clinic detail manage',
      },
      DOC_CLINIC_USER_VIEW: {
        PERMISSION_CODE: 'DOC_CLINIC_USER_VIEW',
        PERMISSION_NAME: 'Doctor - Doctor Clinic user view',
      },
      DOC_CLINIC_USER_MANAGE: {
        PERMISSION_CODE: 'DOC_CLINIC_USER_MANAGE',
        PERMISSION_NAME: 'Doctor - Doctor Clinic user manage',
      },
    },
    AUTHORIZATION_CATEGORY: 'DOCTOR_CLINIC',
  },
  DIAGNOSTIC_CENTER: {
    PERMISSIONS: {
      DIAG_APPOINTMENTS_VIEW: {
        PERMISSION_CODE: 'DIAG_APPOINTMENTS_VIEW',
        PERMISSION_NAME: 'Diagnostics - View Appointments',
      },
      DIAG_APPOINTMENTS_MANAGE: {
        PERMISSION_CODE: 'DIAG_APPOINTMENTS_MANAGE',
        PERMISSION_NAME: 'Diagnostics - Manage Appointments',
      },
      DIAG_APPOINTMENTS_LOGS_VIEW: {
        PERMISSION_CODE: 'DIAG_APPOINTMENTS_LOGS_VIEW',
        PERMISSION_NAME: 'Diagnostics - View Appointment Logs',
      },
      DIAG_APPOINTMENTS_LOGS_MANAGE: {
        PERMISSION_CODE: 'DIAG_APPOINTMENTS_LOGS_MANAGE',
        PERMISSION_NAME: 'Diagnostics - Manage Appointment Logs',
      },
      DIAG_TESTS_VIEW: {
        PERMISSION_CODE: 'DIAG_TESTS_VIEW',
        PERMISSION_NAME: 'Diagnostics - View Tests',
      },
      DIAG_TESTS_MANAGE: {
        PERMISSION_CODE: 'DIAG_TESTS_MANAGE',
        PERMISSION_NAME: 'Diagnostics - Manage Tests',
      },
      DIAG_PACKAGES_VIEW: {
        PERMISSION_CODE: 'DIAG_PACKAGES_VIEW',
        PERMISSION_NAME: 'Diagnostics - View Packages',
      },
      DIAG_PACKAGES_MANAGE: {
        PERMISSION_CODE: 'DIAG_PACKAGES_MANAGE',
        PERMISSION_NAME: 'Diagnostics - Manage Packages',
      },
      DIAG_CENTER_INFO_VIEW: {
        PERMISSION_CODE: 'DIAG_CENTER_INFO_VIEW',
        PERMISSION_NAME: 'Diagnostics - View Profile',
      },
      DIAG_CENTER_INFO_MANAGE: {
        PERMISSION_CODE: 'DIAG_CENTER_INFO_MANAGE',
        PERMISSION_NAME: 'Diagnostics - Manage profile',
      },
      DIAG_REPORT_VIEW: {
        PERMISSION_CODE: 'DIAG_REPORT_VIEW',
        PERMISSION_NAME: 'Diagnostics - View Test Reports',
      },
      DIAG_REPORT_MANAGE: {
        PERMISSION_CODE: 'DIAG_REPORT_MANAGE',
        PERMISSION_NAME: 'Diagnostics - Manage Test Reports',
      },
      DIAG_USERS_VIEW: {
        PERMISSION_CODE: 'DIAG_USERS_VIEW',
        PERMISSION_NAME: 'Diagnostics - View Users',
      },
      DIAG_USERS_MANAGE: {
        PERMISSION_CODE: 'DIAG_USERS_MANAGE',
        PERMISSION_NAME: 'Diagnostics - Manage Users',
      },
    },
    AUTHORIZATION_CATEGORY: 'DIAGNOSTIC_CENTER',
  },
  RECIPIENT: {
    AUTHORIZATION_CATEGORY: 'RECIPIENT',
    PERMISSIONS: {
      REC_MY_ACCOUNT_PROFILE_VIEW: {
        PERMISSION_CODE: 'REC_MY_ACCOUNT_PROFILE_VIEW',
        PERMISSION_NAME: 'Recipient - View My Profile',
      },
      REC_MY_ACCOUNT_PROFILE_EDIT: {
        PERMISSION_CODE: 'REC_MY_ACCOUNT_PROFILE_EDIT',
        PERMISSION_NAME: 'Recipient - Edit My Profile',
      },
      REC_MY_ACCOUNT_FAMILY_DETAIL_VIEW: {
        PERMISSION_CODE: 'REC_MY_ACCOUNT_FAMILY_DETAIL_VIEW',
        PERMISSION_NAME: 'Recipient - View Family Members',
      },
      REC_MY_ACCOUNT_FAMILY_DETAIL_MANAGE: {
        PERMISSION_CODE: 'REC_MY_ACCOUNT_FAMILY_DETAIL_MANAGE',
        PERMISSION_NAME: 'Recipient - Manage Family Members',
      },
      REC_MY_ACCOUNT_SEND_INVITE: {
        PERMISSION_CODE: 'REC_MY_ACCOUNT_SEND_INVITE',
        PERMISSION_NAME: 'Recipient - Send an Invite',
      },
      REC_MY_APPOINTMENTS_VIEW: {
        PERMISSION_CODE: 'REC_MY_APPOINTMENTS_VIEW',
        PERMISSION_NAME: 'Recipient - Manage  My Appointments',
      },
      REC_MY_FAVORITES_VIEW: {
        PERMISSION_CODE: 'REC_MY_FAVORITES_VIEW',
        PERMISSION_NAME: 'Recipient - View My Favorites',
      },
      REC_MY_FAVORITES_MANAGE: {
        PERMISSION_CODE: 'REC_MY_FAVORITES_MANAGE',
        PERMISSION_NAME: 'Recipient - Manage My Favorites',
      },
      REC_MY_NOTIFICATIONS_VIEW: {
        PERMISSION_CODE: 'REC_MY_NOTIFICATIONS_VIEW',
        PERMISSION_NAME: 'Recipient - View My Notifications',
      },
      REC_MY_NOTIFICATIONS_MANAGE: {
        PERMISSION_CODE: 'REC_MY_NOTIFICATIONS_MANAGE',
        PERMISSION_NAME: 'Recipient - Manage My Notifications',
      },
      REC_HOME_CHANGE_LOCATION: {
        PERMISSION_CODE: 'REC_HOME_CHANGE_LOCATION',
        PERMISSION_NAME: 'Recipient - Change Location',
      },
      REC_BOOK_NEW_APPOINTMENT: {
        PERMISSION_CODE: 'REC_BOOK_NEW_APPOINTMENT',
        PERMISSION_NAME: 'Recipient - Book New Appointment',
      },
      REC_ECOMM_PLACE_ORDER: {
        PERMISSION_CODE: 'REC_ECOMM_PLACE_ORDER',
        PERMISSION_NAME: 'Recipient - Place New Order',
      },
    },
  },
};
export default permissions;
