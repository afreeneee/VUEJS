import config from '@/app/utils/config';
import Utility from '@/app/services/Utility';
import permissions from './Permissions';
import JWT from './JWT';

/*
* This function is for checking token stored in local storage
*/
const isAuth = function isAuth() {
  if (Utility.getStorage(config.tokenKeyName)) {
    return !JWT.isTokenExpired(Utility.getStorage(config.tokenKeyName));
  }
  return false;
};
/*
* This function is for login and set token in local storage
*/
const login = function login(token) {
  if (token != undefined || token != null) { // eslint-disable-line
    Utility.setStorage(config.tokenKeyName, token);
  }
  return isAuth();
  console.log(this.auth)
};
/*
* This function is for logout and and remove token from local storage
*/
const logout = function logout() {
  Utility.removeStorage(config.tokenKeyName);
   return isAuth();
};
/*
* This function is for fetching details of user from token
*/
const getDetails = function getDetails() {
  return JWT.decodeToken(Utility.getStorage(config.tokenKeyName));
};
/*
* This function is for token expiration
*/
const sessionValidTill = function sessionValidTill() {
  return JWT.getTokenExpirationDate(Utility.getStorage(config.tokenKeyName));
};
/*
* This function is for token has exist in local storage
*/
const hasToken = function hasToken() {
  if (Utility.getStorage(config.tokenKeyName)) {
    return true;
  }
  return false;
};

/*
* Method to check loggedin user's permissions.
*/
const hasPermission = function hasPermission(categoryAndCode) { // format is category.code
  // checks if category and code is defined or not
  if (categoryAndCode === null || categoryAndCode === '' || categoryAndCode === undefined) {
    return true;
  }
  const params = categoryAndCode.split('.');
  if (params.length !== 2) {
    return false;
  }

  // checks if given category of user and action is same and category exists
  const permissiosOfUser = getDetails().auth;
  const categoryOfUser = getDetails().authCategory;
  if (categoryOfUser !== params[0] || !permissions[categoryOfUser]) {
    return false;
  }

  // checks if permissions code matches with given auth of token
  const authPermission = permissiosOfUser.split(',');
  const findPermission = authPermission.indexOf(permissions[categoryOfUser]
    .PERMISSIONS[params[1]].PERMISSION_CODE);
  if (findPermission > -1) {
    return true;
  }
  return false;
};

export default {
  isAuth,
  login,
  logout,
  getDetails,
  sessionValidTill,
  hasToken,
  hasPermission,
};
