import Vue from 'vue';
import Auth from './Auth';
import Password from './Password';

Vue.prototype.$auth = Auth;
Vue.prototype.$password = Password;
