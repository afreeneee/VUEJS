/**
 * This is where all the authorization login is stored
 */
import Auth from '../auth/Auth';

import Authorization from '../Authorization';

export default function HasPermissions(router) {
  /**
   * Before each route we will see if the current user is authorized
   * to access the given route
   */
  router.beforeEach((to, from, next) => {
    let authorized = false;
    // let user = JSON.parse(window.localStorage.getItem('auth-user'))
    /**
     * Remember that access object in the routes? Yup this why we need it.
     *
     */
    const access = to.meta.permissions;
    if (access !== undefined) {
      authorized = Authorization.authorize(access, to);

      if (authorized === 'loginIsRequired') {
        router.push({ name: 'LoginLayout' });
      } else if (authorized === 'notAuthorized' && Auth.getDetails().redirect_url) {
        router.replace({ path: Auth.getDetails().redirect_url });
      } else if (authorized === 'notAuthorized') {
        router.push({ name: 'LoginLayout' });
      }
    }
    next();
  });
}
