import Auth from '../auth/Auth';
// import config from '@/app/config';

export default function IsRouteAllowed(router) {
  /**
   * If the user is already authenticated he shouldn't be able to visit
   * pages like login, register, etc...
   */

  router.beforeEach((to, from, next) => {
    /**
     * Checks if there's a token and the next page name is none of the following
     */
    if (!Auth.isAuth() && to.meta.isAuthRequired) {
      router.replace({ name: 'login', query: { redirect: to.fullPath } });
    }
    if (!Auth.isAuth() && from.name === null && to.name === null && (to.name !== 'HomeLandingLayout')) {
      router.replace({ name: 'HomeLandingLayout' });
    }

    if (Auth.isAuth() && (to.name === 'login' || to.name === 'signup' || to.name === 'forgotPassword')) {
      router.replace({ name: 'HomeLandingLayout' });
    }

    if (Auth.isAuth() && Auth.getDetails().redirect_url && to.meta.hasOwnProperty('category') && // eslint-disable-line
    (to.meta.category !== Auth.getDetails().authCategory)) {
      // && Auth.getDetails().redirect_url !== to.fullPath
      router.replace({ path: Auth.getDetails().redirect_url });
    }
    /**
     * Checks if token is either expired or malicious.
     */
    if (!Auth.isAuth() && Auth.hasToken()) {
      Auth.logout();
      router.replace({ name: 'login' });
    }
    next();
  });
}
