import UserHasPermissions from './HasPermissions';
import RedirectIfAuthenticated from './IsRouteAllowed';

export default function middleware(router) {
  UserHasPermissions(router);
  RedirectIfAuthenticated(router);
}
