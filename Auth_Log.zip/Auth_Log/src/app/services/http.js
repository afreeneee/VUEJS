import axios from 'axios';
import router from '@/router/index';
import config from '../utils/config';
import Utility from './Utility';

const splitToken = function (token) {
  const authToken = token.split(' ');
  alert(authToken);
  return authToken[1];
}

const redirectUnAuth = function (response) {
  if(response.status === 401){
    Utility.removeStorage(config.tokenKeyName);
    router.replace({ name: 'login' });
  }
};

axios.interceptors.request.use(function (request) {
  const token = Utility.getStorage(config.tokenKeyName);
  if (token && request.url.indexOf('payload-url') <= -1  && request.url.indexOf('geocode') <= -1 ) {
    request.headers = request.headers || {};
    request.headers.Authorization = `Bearer ${token}`;
    request.headers.languageCode = 'en';
    request.headers.lang_code = 'en';
  }
  if (token && request.url.indexOf('switch-profile') > -1) {
    request.headers['Switch-Profile'] = 'Yes';
  }
  return request;
}, function requestError(error) {
  // Do something with request error
  return Promise.reject(error);
});

axios.interceptors.response.use(function (response) {
  redirectUnAuth(response);
  if (response.status === 200 && response.data.success && response.headers.authorization) {
    Utility.setStorage(config.tokenKeyName, splitToken(response.headers.authorization));
  }
  // const request = response.config;
  return response;
}, function responseError(error) {
  const {
    response,
    config: request
  } = error;
  /**
   * Checks if token is either expired and apis return .
   */
  redirectUnAuth(response);
  if (response) {
    return Promise.resolve({ response: response });
  }
  // return Promise.resolve({response: response});

  if (config.debug.http) {
    const {
      response,
      config: request
    } = error;
  }
  // Do something with response error
  return Promise.reject(error);
})

export default axios;
