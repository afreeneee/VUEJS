import Auth from './auth/Auth';

export default {
  authorize(requiredPermissions, to) {
    let result = 'authorized';
    let hasPermissionToMove = true;
    let permission;
    let permissionIndex;
    const permissionsArray = requiredPermissions;
    if (permissionsArray.length === 0 && to.meta.hasOwnProperty('category')&& (to.meta.category // eslint-disable-line
    === Auth.getDetails().category)) { // eslint-disable-line
      return 'authorized';
    }

    if (permissionsArray.length > 0 && to.meta.hasOwnProperty('category') && (to.meta.category // eslint-disable-line
    === Auth.getDetails().authCategory)) { // eslint-disable-line
      for (permissionIndex = 0; permissionIndex < permissionsArray.length;
        permissionIndex += 1) {
        permission = permissionsArray[permissionIndex];
        if (Auth.hasPermission(permission)) {
          hasPermissionToMove = 1;
          break;
        } else {
          hasPermissionToMove = 0;
        }
      }
      result = hasPermissionToMove ? 'authorized' : 'notAuthorized';
    }
    return result;
  },
};
