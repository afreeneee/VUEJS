
export default {
  setStorage(name, value) {
    window.localStorage.setItem(name, value);
  },
  getStorage(name) {
    return window.localStorage.getItem(name) || null;
  },

  removeStorage(name) {
    window.localStorage.removeItem(name);
  },

  clearStorage() {
    window.localStorage.clear();
  },
  /*
  *This method is for convert 24 hours format to 12 hours
  */
  convertTime(tym24Hour) { // time in 24 hours format like "13:30"
    let ts;
    if (tym24Hour !== '') {
      ts = tym24Hour;
      const H = +ts.substr(0, 2);
      let h = (H % 12) || 12;
      h = (h < 10) ? ('0' + h) : h;  // eslint-disable-line
      const ampm = H < 12 ? ' AM' : ' PM';
      ts = h + ts.substr(2, 3) + ampm;
    }
    return ts;
  },
  /**
   * This method is for get dom based on class name
   */
  getDomByClassName: (className) => document.getElementsByClassName(className), // eslint-disable-line
  /**
  * This method is for disable alphabets in Mobile Number input text
  */
  isMobileKey: (event) => {
    const charCode = (event.which) ? event.which : event.keyCode;
    if ((charCode < 48 || charCode > 57)) {
      return false;
    }
    return true;
  },
  escapeRegExp(string) {
    return string.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); // eslint-disable-line
  },
  replaceAll(str, term, replacement) {
    return str.replace(new RegExp(this.escapeRegExp(term), 'g'), replacement);
  },
  checkResponse(response) {//eslint-disable-line
    if (response.status === 200) {
      if (response.data.success) {
        return response;
      }
    } else {
      const data = {
        errorData: response.response.data,
        data: {
          data: {
            doctorListing: [],
          },
          metaInfo: {
            number: 0,
          },
        },
      };
      return data;
    }
  },
  /**
* This function procide a functionality to find city
* via a lat long of localstorage.
*/
  getCityNameByLatLong(store) {
    const geoLatitude = this.getStorage('geoLocationLatitude') ? this.getStorage('geoLocationLatitude') : '';
    const geoLongitude = this.getStorage('geoLocationLongitude') ? this.getStorage('geoLocationLongitude') : '';
    const data = { latitude: geoLatitude, longitude: geoLongitude };
    if (geoLatitude !== '' && geoLongitude !== '') {
      store.dispatch('home/getLocation', data);
      // this.$store.dispatch('home/getDoctors');
    }
  },
  setLatLong(latitude, longitude) {
    this.setStorage('geoLocationLatitude', latitude);
    this.setStorage('geoLocationLongitude', longitude);
  },
  formatString(val) {
    if (val) {
      let value = val;
      value = value.replace(' ', '-');
      value = value.toLowerCase();
      return value;
    }
    return val;
  },
  checkPhoneNumber(number) {
    if (number) {
      if (number.length === 10) {
        return number;
      }
      if (number.startsWith('+91')) {
        return number.slice(-10);
      }
    }
    return number;
  },
  changeNumber(number) {
    if (number) {
      if (number.length === 10) {
        const addition = '+91';
        return addition + number;
      }
    }
    return number;
  },
};
