<template>
  <div id="app">
    <app-header v-if="headerFlag"></app-header>    
       <div class="alert alert-success">            
          </div>
    <router-view></router-view>    
  </div>
</template>

<script>
    import Header from './components/recipient/layout/Header/header';
  /* import Footer from './components/recipient/layout/Footer/footer';*/
  
  export default {
    name: 'app',
    components: {
      'app-header': Header,
    },
    data() {
      return {
        headerFlag: false,
      };
    },
      mounted() {
      // setTimeout(() => {
      //   const chatBot = document.getElementsByClassName('zsiq_floatmain zsiq_theme1');
      //   if (this.$route.fullPath === '/') { //eslint-disable-line
      //     if (chatBot) { //eslint-disable-line
      //       chatBot[0].style.visibility = '';
      //       chatBot[0].style.display = 'block';
      //     }
      //   } else { //eslint-disable-line
      //     if (chatBot) { //eslint-disable-line
      //       chatBot[0].style.visibility = 'hidden';
      //       chatBot[0].style.display = 'none';
      //     }
      //   }
      // }, 4000);
    },
    methods: {
      openMessage(props) {
        props.close();
        this.$router.push({
          name: 'myConsultation',
          query: {
            initCall: false,
            item: JSON.parse(props.item.text).groupId,
          },
        }); //eslint-disable-line
      },
    },
    watch: {
      $route: {
        handler() {
          const to = this.$route;
          this.headerFlag = to.meta.hasOwnProperty('headerFlag') ? to.meta.headerFlag : true; // eslint-disable-line
          //this.footerFlag = to.meta.hasOwnProperty('footerFlag') ? to.meta.footerFlag : true; // eslint-disable-line
          window.scrollTo(0, 0);
          // const chatBot = document.getElementsByClassName('zsiq_floatmain zsiq_theme1');
          // if (this.$route.fullPath === '/') { //eslint-disable-line
          //   if (chatBot) { //eslint-disable-line
          //     chatBot[0].style.visibility = '';
          //     chatBot[0].style.display = 'block';
          //   }
          // } else { //eslint-disable-line
          //   if (chatBot) { //eslint-disable-line
          //     chatBot[0].style.visibility = 'hidden';
          //     chatBot[0].style.display = 'none';
          //   }
          // }
        },
        deep: true,
      },
    },
  };
</script>

<style lang="scss">
  @import "../../node_modules/bootstrap/dist/css/bootstrap.min.css";
  @import "../../node_modules/bootstrap-vue/dist/bootstrap-vue.css";
  /*@import ".~@/assets/scss/app";*/
  .close-noti {
    float: right;
    font-size: 20px;
    font-weight: bold;
    line-height: 18px;
    color: #000000;
    text-shadow: 0 1px 0 #ffffff;
    opacity: 0.2;
    filter: alpha(opacity=20);
  }
  
  .close-noti:hover {
    color: #000000;
    text-decoration: none;
    opacity: 0.4;
    filter: alpha(opacity=40);
    cursor: pointer;
  }
  
  .notification-wrapper {
    cursor: pointer;
  }
    .alert {
    padding: 8px 35px 8px 14px;
    margin-bottom: 18px;
    text-shadow: 0 1px 0 rgba(255, 255, 255, 0.5);
    background-color: #fcf8e3;
    border: 1px solid #fbeed5;
    -webkit-border-radius: 4px;
    -moz-border-radius: 4px;
    border-radius: 4px;
    color: #c09853;
  }
  .alert .close-noti {
    position: relative;
    top: -2px;
    right: -21px;
    line-height: 18px;
  }
  .alert-success {
    background-color: #dff0d8;
    border-color: #d6e9c6;
    color: #468847;
  }
  .alert-error {
    background: #E54D42;
    border-color: #B82E24;
    color: #ffffff;
  }
  .alert-block {
    padding-top: 14px;
    padding-bottom: 14px;
  }
  .alert-block > p,
  .alert-block > ul {
    margin-bottom: 0;
  }
  .alert-block p + p {
    margin-top: 5px;
  }
</style>
