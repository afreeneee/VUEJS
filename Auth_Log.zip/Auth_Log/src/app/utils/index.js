import constants from './constants';

const config = {  
  api: {
    GATEWAY: {
      LOGIN_API_URL: `${constants.GATEWAY_URL}/authenticate`,
      REGISTER_URL: `${constants.GATEWAY_URL}/recipient/register`,
      REGISTER_VERIFY_OTP_URL: `${constants.GATEWAY_URL}/verify-mobile`,
      FORGOT_PASSWORD_OTP_URL: `${constants.GATEWAY_URL}/forgot-password/verify-otp`,
      RESET_PASSWORD_URL: `${constants.GATEWAY_URL}/forgot-password/ghost-user/password`,
      REGISTER_VERIFY_RESEND_OTP_URL: `${constants.GATEWAY_URL}/forgot-password/send-otp`,     
      },
      //alert(LOGIN_API_URL);
  },
  
  timeout: 1000000,
  
};

export default config;
