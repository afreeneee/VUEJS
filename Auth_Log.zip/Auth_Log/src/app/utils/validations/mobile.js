const regexMobile = '^[5-9][0-9]{9}$'; // eslint-disable-line

const customMobile = {
  /* eslint-env es6 */
  // { "before": true, "after": true }
  getMessage:field => 'Please enter valid mobile no.', // eslint-disable-line
  validate: value => { // eslint-disable-line
    const mobileRegex = new RegExp(regexMobile);
    return mobileRegex.test(value);
  },
};
export default customMobile;
