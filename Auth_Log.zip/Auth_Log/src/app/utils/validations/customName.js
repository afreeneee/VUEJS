const regexName = '^[a-zA-Z\\s]*$'; // eslint-disable-line

const fullName = {
  getMessage:field => 'Please enter valid name', // eslint-disable-line
  validate: value => { // eslint-disable-line
    const nameRegex = new RegExp(regexName);
    return nameRegex.test(value);
  },
};

export default fullName;
