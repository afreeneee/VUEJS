import config from './config';

const API_PRE = 'api';
const Size = 10;
const GATEWAY_URL = `${config.gatewayUrl}/zoylogateway-0.0.1-SNAPSHOT`;
const DOCTOR_GATEWAY_URL = `${config.doctorUrl}/zoylodoctor-0.0.1-SNAPSHOT`;
const RECIPIENT_GATEWAY_URL = `${config.recipientUrl}/zoylorecipient-0.0.1-SNAPSHOT`;
const DIAGNOSTIC_GATEWAY_URL = `${config.diagnosticUrl}/zoylodiagnosticservice-0.0.1-SNAPSHOT`;
const ADMIN_URL = `${config.adminUrl}/zoyloadmin-0.0.1-SNAPSHOT`;
const EHEALTH_URL = `${config.ehealthUrl}/zoyloehealth-0.0.1-SNAPSHOT`;

const CONSTANTS = {
  CMS_URL: config.cms_url,
  RECIPIENT_GATEWAY_URL: `${RECIPIENT_GATEWAY_URL}/${API_PRE}`,
  ADMIN_GATEWAY_URL: `${ADMIN_URL}/${API_PRE}`,
  ZOYLO_GATEWAY_URL: `${GATEWAY_URL}/${API_PRE}`,
  DOCTOR_GATEWAY_URL: `${DOCTOR_GATEWAY_URL}/${API_PRE}`,
  GATEWAY_URL: `${GATEWAY_URL}/${API_PRE}`,
  ZOYLO_EHEALTH_URL: `${EHEALTH_URL}/${API_PRE}`,
  DIAGNOSTIC_GATEWAY_URL: `${DIAGNOSTIC_GATEWAY_URL}/${API_PRE}`,
  ECOMM_BASE_URL: `${config.ecomBaseURL}rest/V1`,
  Size,
  jidKey: config.jidKey,
  groupKey: config.groupKey,
  websocketUrl: config.websocketUrl,
  GOOGLE_GET_LOCATION_BY_CITY: `https://maps.googleapis.com/maps/api/geocode/json?key=${config.googleLocationKey}`,
  getIpApiUrl: 'https://api.ipify.org?format=json',
  JIRA_CREATE_ISSUE: 'https://zoyloteam.atlassian.net/rest/api/2/issue',
  dateFormat: 'YYYY-MM-DD',
  timeFormat: 'HH:mm:ss',
  DAY_BREAK_LOOKUP_CODE: 'DAY_BREAKUP_CODE',
  PROVIDER_PAYMENT_MODE: 'PROVIDER_PAYMENT_MODE',
  PROVIDER_FACILITIES: 'PROVIDER_FACILITY',
  serviceProviderCode: 'PROVIDER_TYPE',
  serviceTypeCode: 'PROVIDER_SERVICE_TYPE',
  diagServiceProviderValueCode: 'DIAGNOSTIC_CENTER',
  clinicServiceProviderValueCode: 'CLINIC',
  packageServiceTypeValueCode: 'PACKAGE',
  doctorConsultationMode: 'DOCTOR_CONSULTATION_MODE',
  generalConsultationCode: 'CONSULTATION_CLINIC_GENERAL',
  onlineModeCode: 'DOCTOR_CONSULTATION_ONLINE',
  onlineChatTypeCode: 'CONSULTATION_ONLINE_CHAT',
  onlineVideoTypeCode: 'CONSULTATION_ONLINE_VIDEO',
  clinicConsulationCode: 'DOCTOR_CONSULTATION_CLINIC',
  queryFromCode: 'RECIPIENT_USER_TYPE',
  queryStatusCode: 'CUSTOMER_QUERY_STATUS',
  queryLookupCode: 'CUSTOMER_QUERY_TYPE',
  roleCategory: 'RECIPIENT',
  bannerImagesUrl: 'https://s3.ap-south-1.amazonaws.com/kellton-images/images/banner/',
  lookupCode: {
    bloodGroup: 'BLOOD_GROUP',
    genderCode: 'GENDER_TYPE',
    DAY_BREAK_LOOKUP_CODE: 'DAY_BREAKUP_CODE',
    serviceProviderCode: 'PROVIDER_TYPE',
    serviceTypeCode: 'PROVIDER_SERVICE_TYPE',
    diagServiceProviderValueCode: 'DIAGNOSTIC_CENTER',
    clinicServiceProviderValueCode: 'CLINIC',
    packageServiceTypeValueCode: 'PACKAGE',
    slotLookupCode: 'ZOYLO_LAB_SLOTS',
    symptomsTypeValueCode: 'ZOYLO_LAB_SYMPTOM',
    organsTypeValueCode: 'ZOYLO_LAB_ORGAN',
    habitsTypeValueCode: 'ZOYLO_LAB_HABIT',
    paymentTypeValueCode: 'PROVIDER_PAYMENT_MODE',
  },
  zoyloTitle: 'Zoylo - Find Doctors,Hospitals, Diagnostics & more India',
  citiesDetails: [
    {
      title: 'Mumbai',
      icon: 'mumbai',
      lat: 18.96667,
      long: 72.83333,
    },
    {
      title: 'Hyderabad',
      icon: 'hyderabad',
      lat: 17.36667,
      long: 78.46667,
    },
    {
      title: 'Delhi',
      icon: 'delhi',
      lat: 28.653458,
      long: 77.123767,
    },
    {
      title: 'Lucknow',
      icon: 'lucknow',
      lat: 26.86056,
      long: 80.91583,
    },
    {
      title: 'Chennai',
      icon: 'chennai',
      lat: 13.09,
      long: 80.27,
    },
    {
      title: 'Ahmedabad',
      icon: 'ahmedabad',
      lat: 23.03,
      long: 72.58,
    },
    {
      title: 'Kolkata',
      icon: 'kolkata',
      lat: 22.54111,
      long: 88.33778,
    },
    {
      title: 'Goa',
      icon: 'goa',
      lat: 15.29299,
      long: 74.030543,
    },
  ],
  mapStyle: {
    styles: [
      {
        featureType: 'administrative',
        elementType: 'geometry',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
      {
        featureType: 'poi',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
      {
        featureType: 'road',
        elementType: 'labels.icon',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
      {
        featureType: 'transit',
        stylers: [
          {
            visibility: 'off',
          },
        ],
      },
    ],
  },
  dayCodes: [{
    daykey: 0,
    day: 'SUNDAY',
    dayCode: 'SUN',
    activeFlag: false,
  },
  {
    daykey: 1,
    day: 'MONDAY',
    dayCode: 'MON',
    activeFlag: false,
  },
  {
    daykey: 2,
    day: 'TUESDAY',
    dayCode: 'TUE',
    activeFlag: false,
  },
  {
    daykey: 3,
    day: 'WEDNESDAY',
    dayCode: 'WED',
    activeFlag: false,
  },
  {
    daykey: 4,
    day: 'THURSDAY',
    dayCode: 'THU',
    activeFlag: false,
  },
  {
    daykey: 5,
    day: 'FRIDAY',
    dayCode: 'FRI',
    activeFlag: false,
  },
  {
    daykey: 6,
    day: 'SATURDAY',
    dayCode: 'SAT',
    activeFlag: false,
  },
  ],
};
export default CONSTANTS;
