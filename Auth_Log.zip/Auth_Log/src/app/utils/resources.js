
const DOC_CONSTANTS = {
  homeImg: require('@/assets/images/logo.png'),
};
export default DOC_CONSTANTS;
