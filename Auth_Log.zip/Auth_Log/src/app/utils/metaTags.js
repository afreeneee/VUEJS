const meta = {
  homeHealthCare: {
    title: 'Home Healthcare Services in India, Healthcare at Home - Zoylo',
    description: ' Zoylo provides best Home Healthcare Services in India - Doctor Visit, Physiotherapy, Nursing, Lab Tests, Home Health Aide & more. Book Appointment Online!',
    keywords: 'Home Healthcare Services, Healthcare at Home, Online Home Care Services in India, In-Home Healthcare Services, Physiotherapy at Home, Nursing Care, Home Nursing Services, Elderly Care Services, Home Medical Care, Home Health Agency, Patient Home Care, Doctor Home Visit',
  },
   forgotPassword: {
    title: 'Forgot Password - Zoylo.com',
    description: 'Enter your e-mail id or mobile number associated with your account and generate OTP to reset your password.',
    keywords: 'forgot password,reset password,OTP,zoylo forgot password,can\'t login',
  },
  login: {
    title: 'Customer Login - Zoylo, Book Appointment Instantly',
    description: 'Sign in with Zoylo and book appointment online with doctors, online diagnostic lab centers, e-health cards, best hospital packages, online medicines, health & wellness products in India',
    keywords: 'find and book best online doctors in India,find and book best online diagnostic centers in India,find best hospital packages in India,order medicines online,book online doctor appointments in India,zoylo patient sign in,zoylo patient login,health and wellness products in India,Hyderabad,Ahmedabad,Chennai,Bangalore,Mumbai,Delhi, Pune,zoylo customer login, zoylo customer sign in.',
  },
  register: {
    title: 'Signup with Zoylo and Access Best Healthcare Services in India',
    description: 'Zoylo, the largest appointment booking platform. If you don\'t have an account, sign up here. Book appointment online instantly and get confirmed appointments.',
    keywords: 'find and book best online doctors in India,find and book best online diagnostic centers in India,find best hospital packages in India,order medicines online,book online doctor appointments in India,zoylo patient signup,zoylo patient registration,health and wellness products,Hyderabad,Ahmedabad,Chennai,Bangalore,Mumbai,Delhi, Pune,zoylo customer login, zoylo customer signup',
  },
  contactUs: {
    title: 'Contact Us - Best Healthcare Service Provider Online | Zoylo',
    description: 'Contact Us for any information regarding our services - Online Doctor Appointment Booking, Online Diagnostic Lab Centres, Hospital Packages, Online Medicines, Wellness Products, E-Health Cards.',
    keywords: 'Contact Us, Online Doctor Appointments, Online Diagnostic Bookings, Hospital Packages, Online Health and Wellness Products, E-Health Cards, Emergency Home Visits, Zoylo',
  },
 };
export default meta;
