const baseGatewayUrl = process.env.BASE_GATEWAY_URL || 'http://13.126.81.88:8080';
const baseAdminUrl = process.env.BASE_ADMIN_URL || 'http://13.127.33.222:8080';
const baseDiagnosticUrl = process.env.BASE_DIAGNOSTIC_URL || 'http://13.127.33.222:8080';
const baseDoctorUrl = process.env.BASE_DOCTOR_URL || 'http://13.127.33.222:8080';
const baseRecipientUrl = process.env.BASE_RECIPIENT_URL || 'http://13.127.33.222:8080';
const baseUrlEHealth = process.env.BASE_URL_EHEALTH;
const baseUrlEcomm = process.env.ECOMM_DEV_BASE_URL;

const config = {
  gatewayUrl: baseGatewayUrl,
  adminUrl: baseAdminUrl,
  diagnosticUrl: baseDiagnosticUrl,
  doctorUrl: baseDoctorUrl,
  recipientUrl: baseRecipientUrl,
  ehealthUrl: baseUrlEHealth,
  ecomUrl: baseUrlEcomm,
  debug: {
    http: process.env.DEBUG || true,
  },
  // api: `${baseUrl}/admin/api`,
  timeout: 1000000,
  forgetPasswordTime: process.env.RESEND_OTP,
  tokenKeyName: process.env.TOKEN_NAME || 'token',
  merchantCode: process.env.MERCHANT_CODE || 'T44949',
  ecomTokenKey: process.env.ECOMM_TOKEN_NAME || 'ecomtoken',
  ecomAdminTokenKey: process.env.ECOMM_ADMIN_ACCESS_TOKEN || 'ecomtokenadmin',
  encryptionKey: process.env.ENCRYPTION_KEY || '1141833881RXSHCY',
  encryptionIv: process.env.ENCRYPTION_IV || '8102195173TXMORT',
  isUat: process.env.IS_UAT || false,
  priceGateway: process.env.PRICE_GATEWAY,
  returnUrl: process.env.RETURN_URL,
  bankCode: process.env.BANK_CODE,
  googleMapKey: process.env.G_MAP_KEY,
  googleLocationKey: process.env.G_GET_LOCATION_KEY,
  dtls: process.env.DTLS,
  schemeCode: process.env.SCHEME_CODE,
  paytmMid: process.env.PAYTM_MID,
  paytmChannelId: process.env.PAYTM_CHANNEL_ID,
  paytmWebsite: process.env.PAYTM_WEBSITE,
  paytmIndustryTypeId: process.env.PAYTM_INDUSTRY_TYPE_ID,
  paytmMerchantKey: process.env.PAYTM_MERCHANT_KEY,
  paytmCallbackUrl: process.env.PAYTM_CALLBACK_URL,
  paytmActionUrl: process.env.PAYTM_ACTION_URL,
  ecomBaseURL: process.env.ECOMM_BASE_URL,
  ecomLoginURL: process.env.ECOMM_LOGIN_URL,
  paytmTheme: process.env.PAYTM_THEME,
  playStoreUrl: process.env.PLAYSTORE_URL,
  appStoreUrl: process.env.APPSTORE_URL,
  websocketUrl: process.env.WEBSOCKET_URL,
  jidKey: process.env.JID_KEY,
  groupKey: process.env.GROUP_KEY,
  chatTokenKeyName: process.env.CHAT_TOKEN_NAME || 'token',
  videoTokenKeyName: process.env.VIDEO_TOKEN_NAME || 'token',
  clevertap_account_id: process.env.CLEVERTAP_ACCOUNT_ID,
  disabledEcomm: process.env.Disabled_ECOMM,
  cms_url: process.env.CMS_URL,
  razorpayAppId: process.env.RAZORPAY_APPID,
  jiraUsername: process.env.JIRA_USERNAME,
  jirapassword: process.env.JIRA_PASSWORDS,
  zoyloEcomCustId: process.env.ECOMM_CUSTOMER_ID,
};

global.config = config;

export default config;
