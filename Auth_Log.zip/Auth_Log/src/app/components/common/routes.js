
const globalComponent = () => import('./globalComponents');


export default [
  {
    path: '/global-component',
    component: globalComponent,
    name: 'globalcomponent',
    meta: {
      headerFlag: false,
    },
  },
];

