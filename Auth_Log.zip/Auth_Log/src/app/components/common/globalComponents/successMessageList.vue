<template>
<div  v-if="showSuccessMessage">
  <div
    class="alert alert-success mt-4 font12"
    role="alert"
    v-for="(message, index) in successMessages"
    :key="index"
    v-html="message"
  ></div>
</div>
</template>
<script>
export default {
  props: {
    successMessages: {
      default: [],
    },
  },
  data() {
    return {
      showSuccessMessage: false,
    };
  },
  watch: {
    successMessages() {
      if (this.successMessages.length) {
        this.showSuccessMessage = true;
        setTimeout(() => {
          this.showSuccessMessage = false;
        }, 5000);
      }
    },
  },
};
</script>

