<template>
    <ul class="rating mr-3">
          <li v-for="(ratings, index) in 5" :key="index">
            <img v-if="index < rating" src="">
            <img v-else src="">
          </li>
        </ul>
</template>
<script>
export default {
  props: {
    rating: {
      type: Number,
      default: 4,
    },
  },
};
</script>

