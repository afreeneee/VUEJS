<template>
  <div class="loader d-flex align-items-center justify-content-center">
   <img src="">
  </div>
</template>

<script>
  export default {
    name: 'loader',
  };
</script>
<style scoped lang="scss">

.loader{
  position: fixed;
  left:0;
  right:0;
  top:0;
  bottom:0;
  background:#fff;
  z-index: 999;
  img {
    border-radius: 50%;
  }
}
</style>