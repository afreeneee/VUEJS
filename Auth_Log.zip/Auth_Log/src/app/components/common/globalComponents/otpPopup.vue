<template>
  <b-modal ref="OTPModal" centered hide-footer no-close-on-esc no-close-on-backdrop title="OTP Verfication">
    <div class="d-block text-center pt-5 px-5">
      <p class="font12 font-medium">An OTP has been sent to your registered mobile number</p>
      <error-message :errorMessages="errorMessagesOTP"></error-message>
      <success-message :successMessages="successMessagesOTP"></success-message>
      <form class="floating-label apply-coupon">
        <div class="form-group mt-0 pt-0 text-left">
          <input
                  type="text"
                  class="form-control"
                  placeholder="Enter OTP"
                  v-model="otpData.otp"
                  name="OTP"
                  maxlength="6"
                  data-vv-name= 'OTP'
                  v-validate="'required|min:6|max:6|numeric'"
          >
          <span v-show="errors.has('OTP')" class="font12 help-block text-danger">
                        {{ errors.first('OTP') }}</span>
          <a href="javascript:void(0)" @click="(count === 0) ? resendOTP() : ''" :class="{ 'apply-link font12 secondary-color' : true, 'disabled' : (count !== 0) }">Resend OTP</a>
        <span class="font12 font-medium">Please wait for {{ count }} seconds</span>
        </div>
        <b-button type="button" variant="primary" @click="verifyOTP">Submit</b-button>
      </form>

    </div>
  </b-modal>
</template>
<script>
import { displayErrorMessage, displaySuccessMessage } from '@/app/utils/responseMessages';

export default {
  props: {
    resendAction: {
      type: String,
      required: true,
    },
    phoneNum: {
      type: String,
      required: true,
    },
    verifyAction: {
      type: String,
      required: true,
    },
    otpDataId: {
      type: String,
      required: false,
    },
  },
  data() {
    return {
      otpData: {},
      errorMessagesOTP: [],
      successMessagesOTP: [],
      count: 60,
    };
  },
  methods: {
    showPopup(id) {
      this.count = 60;
      this.setCounter();
      this.otpData.id = id;
      this.$refs.OTPModal.show();
    },
    hidePopup() {
      this.$refs.OTPModal.hide();
    },
    verifyOTP() {
      this.$validator.validateAll().then(async (status) => {
        if (status) {
          const response = await this.$store.dispatch(this.verifyAction, this.otpData);
          if (response.status === 200 && response.data.success) {
            this.hidePopup();
            let responseData = '';
            if (response.data.data && response.data.data.token) {
              responseData = response.data.data.token;
            } else {
              responseData = true;
            }
            this.$emit('otpVerify', responseData);
          } else if (response.data) {
            this.errorMessagesOTP = displayErrorMessage(response.data.errorCodeList);
          } else {
            this.errorMessagesOTP = displayErrorMessage(response.response.data.errorCodeList);
          }
        }
      });
    },
    resendOTP() {
      this.$store.dispatch(this.resendAction, this.phoneNum).then((response) => {
        this.count = 60;
        this.setCounter();
        if (response.status === 200 && response.data.success) {
          if (response.data.data.id) {
            this.otpData.id = response.data.data.id;
          } else {
            this.otpData.id = response.data.data;
          }
          this.serverSuccessOTP = displaySuccessMessage(response.data.infoCode);
        } else if (response.data) {
          this.errorMessagesOTP = displayErrorMessage(response.data.errorCodeList);
        } else {
          this.errorMessagesOTP = displayErrorMessage(response.response.data.errorCodeList);
        }
      });
    },
    setCounter() {
      const time = setInterval(() => {
        if (this.count > 0) {
          this.count = this.count - 1;
        } else {
          clearInterval(time);
        }
      }, 1000);
    },
  },
};
</script>
<style lang="scss" scoped>
  .disabled {
    cursor: auto;
    color: #a0a0a0;
  }
</style>
