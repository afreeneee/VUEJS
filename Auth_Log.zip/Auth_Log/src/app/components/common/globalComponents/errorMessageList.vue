<template>
<div  v-if="showErrorMessage">
  <div
    class="alert alert-danger mt-4 font12"
    role="alert"
    v-for="(message, index) in errorMessages"
    :key="index"
    v-html="message"
  ></div>
</div>
</template>
<script>
export default {
  props: {
    errorMessages: {
      default: [],
    },
  },
  data() {
    return {
      showErrorMessage: false,
    };
  },
  watch: {
    errorMessages() {
      if (this.errorMessages.length) {
        this.showErrorMessage = true;
        setTimeout(() => {
          this.showErrorMessage = false;
        }, 5000);
      }
    },
  },
};
</script>

