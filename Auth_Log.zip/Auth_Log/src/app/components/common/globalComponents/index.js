/**
 * Import your components
 * You can register global components here and use them as a plugin in your main Vue instance
 */
export { default as routes } from '../routes'; // eslint-disable-line

const GlobalComponents = {
  install(Vue) {
    Vue.component('location-search-box', () => import('./locationSearch.vue'));
    Vue.component('error-message', () => import('./errorMessageList.vue'));
    Vue.component('success-message', () => import('./successMessageList.vue'));
    Vue.component('otp-modal', () => import('./otpPopup.vue'));
    Vue.component('rating', () => import('./rating.vue'));
    Vue.component('loader', () => import('./loader.vue'));
  },
};

export default GlobalComponents;
