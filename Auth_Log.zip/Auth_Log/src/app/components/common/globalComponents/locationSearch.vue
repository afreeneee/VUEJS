<template>
  <GmapAutocomplete ref="autocomplete" :options="{ componentRestrictions: {country: 'IN'}, }" @place_changed="setPlace" id="location-detect" size="lg" class="location-input form-control form-control-lg" type="text" placeholder="Enter Your Location" :value="selectedOption" v-validate="'required'"
    @change="onChange" @focus="OnFocus" :disabled="setDisabled">
  </GmapAutocomplete>
</template>

<script>
  import VeeValidate from 'vee-validate'; // eslint-disable-line
  import Utility from '@/app/services/Utility';

  export default {
    props: {
      setDisabled: {
        type: Boolean,
        default: false,
      },
    },
    data() {
      return {
        showGoogle: false,
        autocompleteText: '',
        isActiveLoader: false,
        markers: [],
        place: null,
      };
    },
    description: '',
    methods: {
      setPlace(place) {
        this.place = place;
        this.setLatLong(this.place.geometry.location.lat(), this.place.geometry.location.lng());
        this.$emit('selected-option');
        this.displayLocation(this.place);
      },
      displayLocation(place) {
        if (place.formatted_address) {
          let city = '';
          for (let i = 0; i < place.address_components.length; i += 1) {
            for (let j = 0; j < place.address_components[i].types.length; j += 1) {
              if (place.address_components[i].types[j] === 'locality') {
                city = place.address_components[i].long_name;
              }
            }
          }
          const location = {
            selectedOption: place.formatted_address,
            selectedCity: city.trim(),
          };
          this.$store.commit('home/LOCATION', location);
          this.place = null;
        }
      },
      hideLoder() {
        setTimeout(() => {
          this.isActiveLoader = false;
        }, 1000);
      },
      setLatLong(latitude, longitude) {
        Utility.setLatLong(latitude, longitude);
        const location = {
          lat: parseFloat(latitude),
          lng: parseFloat(longitude),
        };
        this.$store.commit('home/CURRENT_LOCATION', location);
      },
      getGeoLocationLatLong(position) {
        this.setLatLong(position.coords.latitude, position.coords.longitude);
        this.getCityNameByLatLong();
      },
      handlePermission() {
        const geoLatitude = Utility.getStorage('geoLocationLatitude') ? Utility.getStorage('geoLocationLatitude') : '';
        const geoLongitude = Utility.getStorage('geoLocationLongitude') ? Utility.getStorage('geoLocationLongitude') : '';
        if (geoLatitude === '' && geoLongitude === '') {
          const that = this;
          if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(that.getGeoLocationLatLong, that.showError);
          } else {
            console.log('Geolocation is not supported by this browser.');
            this.getLocationManually();
          }
        } else {
          this.getCityNameByLatLong();
        }
      },
      getCityNameByLatLong() {
        Utility.getCityNameByLatLong(this.$store);
      },
      showError() {
        this.getLocationManually();
      },
      getLocationManually() {
        this.$emit('manual-location');
      },
      OnFocus() {
        this.$emit('keypress-event', false);
      },
      /**
       * When the input got changed
       */
      onChange(event) {
        if (event.target.value.length === 0) {
          const location = {
            selectedOption: '',
            selectedCity: '',
          };
          this.$store.commit('home/LOCATION', location);
        }
      },
    },
    created() {
      this.$root.$on('current-location', () => {
        const that = this;
        navigator.geolocation.getCurrentPosition(that.getGeoLocationLatLong, that.showError);
      });
      this.handlePermission();
    },
    computed: {
      selectedOption() {
        return this.$store.getters['home/city'].selectedOption;
      },
    },
  };
</script>
