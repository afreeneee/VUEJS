<template>
  <div class='home'>
    <router-view></router-view>
  </div>
</template>
<script>
export default {
  name: 'Auth',
};
</script>
<style>
</style>