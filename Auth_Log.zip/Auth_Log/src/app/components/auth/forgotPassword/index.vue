<template>
  <div class="registeration-container d-flex align-items-center justify-content-center align-content-center">
    <loader v-if="isLoading"></loader>
    <div class="registration-content">
        <h6 class=" font-regular text-center">Forgot Password</h6>
        <error-message :errorMessages="errorMessages"> </error-message>
        <form class="floating-label" @submit.prevent="onSubmit">
          <div class="form-group required">
            <input type="text" class="form-control" id="phoneLbl"  v-model="phoneNumber" value="" name="mobile" data-vv-name= 'phone' maxLength="10"  v-validate="'required|numeric|min:10|max:10|mobile'">
            <label for="phoneLbl">Mobile Number</label>
            <span v-show="errors.has('phone')" class="font12 help-block text-danger" >
              {{ errors.first('phone') }}</span>
          </div>
          <div class="d-flex align-items-center justify-content-end">

          </div>
          <b-button type="submit" variant="primary" class="w-100 fa fa-spinner">Submit</b-button>
        </form>
          <div class="font14 grey-text text-center"> Back to  <router-link v-bind:to ="'/login'" class="font-medium secondary-color">Sign In</router-link></div>
    </div>
      
  </div>


</template>
<script src="./forgotPassword.js"></script>
<style src="./forgotPassword.css"></style>
