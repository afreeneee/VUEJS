import { displayErrorMessage } from '@/app/utils/responseMessages';
import { getField } from 'vuex-map-fields';
import mobile from '@/app/utils/validations/mobile';
import config from '@/app/utils/metaTags';

export default {
  head: {
    title() {
      return {
        inner: config.forgotPassword.title,
        separator: ' ',
        complement: ' ',
      };
    },
    meta() {
      return [
        {
          name: 'title',
          content: config.forgotPassword.title,
          id: 'title',
        },
        {
          name: 'description',
          content: config.forgotPassword.description,
          id: 'desc',
        },
        {
          name: 'keywords',
          content: config.forgotPassword.keywords,
          id: 'keywords',
        },
      ];
    },
  },
  data() {
    return {
      credentials: {
        username: '',
        password: '',
        roleCategory: 'RECIPIENT', // default role category
      },
      errorMessages: [],
      otpData: {},
      isLoading: false,
      otp_verify_action: 'auth/forgotPasswordOTP',
      otp_resend_action: 'auth/resendVerifyRegisterOTP',
    };
  },
  computed: {
    ...getField('auth', {
      phoneNumber: 'userDetails.phoneNumber',
    }),
  },
  created() {
    this.$validator.extend('mobile', mobile);
  },
  beforeDestroy() {
    document.getElementsByTagName('body')[0].classList.remove('pt-0');
  },
  mounted() {
    const bool = document.getElementsByTagName('body')[0].classList.contains('pt-0');
    if (!bool) {
      document.getElementsByTagName('body')[0].classList.add('pt-0');
    }
  },
  methods: {
    /**
     * @method: onSubmit()
     * @description: Method is used when user clicks forget password
    */
    async onSubmit() {
      const valid = await this.$validator.validate();
      if (valid) {
        this.isLoading = true;
        this.$store.dispatch(this.otp_resend_action, this.phoneNumber).then((response) => {
          this.isLoading = false;
          if (response.status === 200 && response.data.success) {
            this.otpData.id = response.data.data;
            this.$refs.OtpModal.showPopup(this.otpData.id);
          } else if (response.data) {
            this.errorMessages = displayErrorMessage(response.data.errorCodeList);
          } else {
            this.errorMessages = displayErrorMessage(response.response.data.errorCodeList);
          }
        });
      }
    },
    changePassword(token) {
      this.$router.push({ name: 'resetPassword', params: { token } });
    },
  },
};
