import configToken from '@/app/utils/config';
import { displayErrorMessage } from '@/app/utils/responseMessages';
import Utility from '@/app/services/Utility';
import mobile from '@/app/utils/validations/mobile';

export default {
name : 'login',
  data() {
    return {
      credentials: {
        phone: '',
        username: '',
        password: '',
      },
      twilioConnection: {},
      errorMessages: [],
      loading: false,
      otpData: {},
      otp_resend_action: 'auth/resendVerifyRegisterOTP',
      otp_verify_action: 'auth/verifyRegisterOTP',
    };
  },
  computed: {
    registerUrl() {
      const redirectPath = this.$route.query.redirect ? this.$route.query.redirect : '';
      if (redirectPath) {
        return `/register?redirect=${redirectPath}`;
      }
      return '/register';
    },
  },
  async created() {
    this.$validator.extend('mobile', mobile);
  },
  beforeDestroy() {
    document.getElementsByTagName('body')[0].classList.remove('pt-0');
  },
  mounted() {
    const bool = document.getElementsByTagName('body')[0].classList.contains('pt-0');
    if (!bool) {
      document.getElementsByTagName('body')[0].classList.add('pt-0');
    }
  },
  methods: {
    /**
     * @method: onSubmit()
     * @description: Method is used to login the user
    */
    async onSubmit() {
      alert(this.credentials.phone);
      alert(this.credentials.password);
      const valid = await this.$validator.validate();
      if (valid) {
        this.loading = true;
        this.$store.dispatch('auth/login', this.credentials).then(async (response) => {
          if (response.status === 200) {
            this.shouldLogin(response);
          } else {
            this.loading = false;
            if (response.response.status === 400 && response.response.data.errorCodeList[0] === 'ERR1011') {
              this.isLoading = true;
              this.$store.dispatch(this.otp_resend_action, this.credentials.phone).then((result) => {
                this.isLoading = false;
                if (result.status === 200 && result.data.success) {
                  this.otpData.id = result.data.data;
                  this.$refs.OtpModal.showPopup(this.otpData.id);
                } else if (response.data) {
                  this.errorMessages = displayErrorMessage(response.data.errorCodeList);
                } else {
                  this.errorMessages = displayErrorMessage(response.response.data.errorCodeList);
                }
              });
            }
            if (response.data) { // eslint-disable-line
              this.errorMessages = displayErrorMessage(response.data.errorCodeList);
            } else {
              this.errorMessages = displayErrorMessage(response.response.data.errorCodeList);
            }
          }
        });
      }
    },
    shouldLogin(response) {
      const setResponse = response.data;
      if (setResponse.success) {
        // set twilio chat token in local storage
        Utility.setStorage(configToken.chatTokenKeyName, setResponse.data.chatToken);
        Utility.setStorage(configToken.ecomTokenKey, setResponse.data.ecommToken);
        Utility.setStorage(configToken.zoyloEcomCustId, setResponse.data.ecommId);
        const redirectPath = this.$route.query.redirect ? this.$route.query.redirect : '';
        if (!redirectPath) {
          this.$router.push({ path: '/' });
        } else if (redirectPath.indexOf('medicines') === -1) {
          this.$router.push({ path: redirectPath });
        } else {
          window.location.href = `${window.location.origin}${redirectPath}`;
        }
      }
      this.loading = false;
    },
    autoLogin(status) {
      if (status) {
        this.loading = true;
        this.$store.dispatch('auth/login', this.credentials).then((response) => {
          this.loading = false;
          if (response.status === 200) {
            this.shouldLogin(response);
          }
        });
      }
    },
  },
};
