<template>
  <div class="registeration-container d-flex align-items-center justify-content-center align-content-center">
    <loader v-if="loading"></loader>
    
    <div class="registration-content">
        <h5 class=" font-regular text-center"> Provide your mobile number to login</h5>
        <error-message :errorMessages="errorMessages"> </error-message>
        <form class="floating-label" @submit.prevent="onSubmit">
          <div class="form-group required m-0">
            <input type="number" class="form-control" id="phoneLbl"  v-model="credentials.phone"   data-vv-name='phone'   v-validate="'required|numeric|min:10|max:10|mobile'">
            <label for="phoneLbl">Mobile Number</label>
            <span v-show="errors.has('phone')" class="font12 help-block text-danger" >
              {{ errors.first('phone') }}</span>
          </div>
          <div class="form-group required m-0 ">
            <input type="password" class="form-control" id="passLbl" v-model="credentials.password"  data-vv-name='password' v-validate="'required'">
            <label for="passLbl">Password</label>
            <span v-show="errors.has('password')" class="font12 help-block text-danger" >
                {{ errors.first('password') }}
        </span>
            <div class="text-right mt-3">
              <router-link v-bind:to ="'/forgot-password'" class="grey-text font14 ">Forgot Password?
              </router-link>
            </div>
          </div>
          <div class="d-flex align-items-center justify-content-end">

          </div>
          <b-button type="submit" variant="primary" class="w-100 fa fa-spinner">Login</b-button>
        </form>
          <div class="font14 grey-text text-center">New to Zoylo?  <router-link v-bind:to ="registerUrl" class="secondary-color font-medium">Sign Up</router-link></div>
      </div>
      <otp-modal ref="OtpModal"
                :resendAction="otp_resend_action"
                :phoneNum="credentials.phone"
                :verifyAction="otp_verify_action"
                :otpDataId="otpData.id"
                @otpVerify="autoLogin"
      ></otp-modal>
  </div>
</template>
<script src="./login.js"></script>
<style src="./login.css"></style>
