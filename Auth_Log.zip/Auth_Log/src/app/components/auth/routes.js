
const Auth = () => import('./auth');
const Login = () => import('./login/');
const signup = () => import('./signup/');
const forgotPassword = () => import('./forgotPassword/');
const resetPassword = () => import('./resetPassword/');

export default [
  {
    path: '/',
    component: Auth,
    name: 'auth',
    children: [
      {
        path: 'login',
        component: Login,
        name: 'login',
        meta: {
          headerFlag: false,
          footerFlag: false,
        },
      },
      {
        path: 'register',
        component: signup,
        name: 'signup',
        meta: {
          headerFlag: false,
          footerFlag: false,
        },
      },
      {
        path: 'forgot-password',
        component: forgotPassword,
        name: 'forgotPassword',
        meta: {
          headerFlag: false,
          footerFlag: false,
        },
      },
      {
        path: 'reset-password/:token',
        component: resetPassword,
        name: 'resetPassword',
        meta: {
          headerFlag: false,
          footerFlag: false,
        },
      },
    ],
  },
];

