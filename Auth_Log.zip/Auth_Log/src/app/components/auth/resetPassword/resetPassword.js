import { displayErrorMessage } from '@/app/utils/responseMessages';

export default {
  data() {
    return {
      errorMessages: [],
      password: '',
      confirmPassword: '',
      token: '',
      isLoading: false,
    };
  },
  beforeDestroy() {
    document.getElementsByTagName('body')[0].classList.remove('pt-0');
  },
  mounted() {
    const bool = document.getElementsByTagName('body')[0].classList.contains('pt-0');
    if (!bool) {
      document.getElementsByTagName('body')[0].classList.add('pt-0');
    }
  },
  methods: {
    /**
     * @method: onSubmit()
     * @description: Method is used when user clicks forget password
    */
    onSubmit() {
       this.validatePassword();
    },
    async validatePassword() {
      const passwordMatch =  await this.$validator.validateAll();
      if (passwordMatch) {
        this.resetPassword();
      };
    },
    async resetPassword() {
      const apiData = {
        newPassword: this.$password.encode(this.password),
        token: this.$route.params.token,
      };
      this.isLoading = true;
      const response = await this.$store.dispatch('auth/resetPassword', apiData);
      this.isLoading = false;
      if (response.data && response.data.success) {
        this.$router.push('/login?success=resetpassword');
      } else if (response.data) {
        this.errorMessages = displayErrorMessage(response.data.errorCodeList);
      } else {
        this.errorMessages = displayErrorMessage(response.errorCodeList);
      };
    },
  },

};
