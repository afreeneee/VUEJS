<template>
  <div class="registeration-container d-flex align-items-center justify-content-center align-content-center">
    
    <loader v-if="isLoading"></loader>
    <div class="registration-content">
        <h6 class=" font-regular text-center">Reset Password</h6>
        <error-message :errorMessages="errorMessages"> </error-message>
        <form class="floating-label" @submit.prevent="onSubmit">
          <div class="form-group required">
            <input type="password" class="form-control" id="newPassword" v-validate="'required'" v-model="password" value="" name="password" data-vv-name= 'password' ref="password">
            <label for="newPassword">Password</label>
            <span v-show="errors.has('password')" class="font12 help-block text-danger" >
              {{ errors.first('password') }}</span>
          </div>
          <div class="form-group required">
            <input type="password" class="form-control" id="confirmPassword" v-validate="'required|confirmed:password'" v-model="confirmPassword" value="" name="confirmPassword" data-vv-as= 'password'>
            <label for="confirmPassword">Confirm Password</label>
            <span v-show="errors.has('confirmPassword')" class="font12 help-block text-danger" >
              {{ errors.first('confirmPassword') }}</span>
          </div>
          <b-button type="submit" variant="primary" class="w-100 fa fa-spinner">Submit</b-button>
        </form>
        <div class="font14 grey-text text-center">Back to  <router-link v-bind:to ="'/login'" class="font-medium secondary-color">Sign In</router-link></div>
    </div>
  </div>
</template>
<script src="./resetPassword.js"></script>
<style src="./resetPassword.css"></style>
