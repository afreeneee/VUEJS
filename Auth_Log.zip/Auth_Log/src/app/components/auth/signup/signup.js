import { getField } from 'vuex-map-fields';
import { displayErrorMessage } from '@/app/utils/responseMessages';
import mobile from '@/app/utils/validations/mobile';
import config from '@/app/utils/metaTags';
import Utility from '@/app/services/Utility';
import configToken from '@/app/utils/config';
/*import { pushClevertapProfile } from '@/app/services/clevertap';*/

export default {
  head: {
    title() {
      return {
        inner: config.register.title,
        separator: ' ',
        complement: ' ',
      };
    },
    meta() {
      return [
        {
          name: 'title',
          content: config.register.title,
          id: 'title',
        },
        {
          name: 'description',
          content: config.register.description,
          id: 'desc',
        },
        {
          name: 'keywords',
          content: config.register.keywords,
          id: 'keywords',
        },
      ];
    },
  },
  name: 'signup',
  data() {
    return {
      isLoading: false,
      otpData: {},
      errorMessages: [],
      otp_resend_action: 'auth/resendVerifyRegisterOTP',
      otp_verify_action: 'auth/verifyRegisterOTP',
    };
  },
  computed: {
    ...getField('auth', {
      firstName: 'userDetails.firstName',
      lastName: 'userDetails.lastName',
      phoneNumber: 'userDetails.phoneNumber',
      emailAddress: 'userDetails.emailAddress',
      encryptedPassword: 'userDetails.encryptedPassword',
    }),
  },
  async created() {
    this.$validator.extend('mobile', mobile);
  },
  beforeDestroy() {
    document.getElementsByTagName('body')[0].classList.remove('pt-0');
  },
  mounted() {
    const bool = document.getElementsByTagName('body')[0].classList.contains('pt-0');
    if (!bool) {
      document.getElementsByTagName('body')[0].classList.add('pt-0');
    }
  },
  methods: {
    onSubmit(evt) {
      evt.preventDefault();
      this.$validator.validateAll().then((valid) => {
        if (valid) {
          this.isLoading = true;
          const data = this.$store.state.auth.userDetails;
          this.$store.dispatch('auth/registerUser', data).then((response) => {
            this.isLoading = false;
            if (response.status === 200 && response.data.success) {
              this.otpData.id = response.data.data.id;
              this.$refs.OtpModal.showPopup(this.otpData.id);
            } else {
              if (response.response.status === 400 && response.response.data.errorCodeList[0] === 'ERR4057') {
                this.isLoading = true;
                this.$store.dispatch(this.otp_resend_action, this.phoneNumber).then((result) => {
                  this.isLoading = false;
                  if (result.status === 200 && result.data.success) {
                    this.otpData.id = result.data.data;
                    this.$refs.OtpModal.showPopup(this.otpData.id);
                  } else if (response.data) {
                    this.errorMessages = displayErrorMessage(response.data.errorCodeList);
                  } else {
                    this.errorMessages = displayErrorMessage(response.response.data.errorCodeList);
                  }
                });
              }
              if (response.data) {
                this.errorMessages = displayErrorMessage(response.data.errorCodeList);
              } else {
                this.errorMessages = displayErrorMessage(response.response.data.errorCodeList);
              }
            }
          });
        }
      });
    },
    autoLogin(status) {
      if (status) {
        const credentials = {
          phone: this.phoneNumber,
          password: this.encryptedPassword,
        };
        this.loading = true;
        const profileData = {
          firstName: this.firstName,
          lastName: this.lastName,
          emailAddress: this.emailAddress,
          phoneNumber: this.phoneNumber,
          lastBookingDate: '',
          lastBookingCategory: '',
          lastBookingPrice: '',
          emailVerified: false,
        };
        this.$store.dispatch('auth/login', credentials).then((response) => {
          this.loading = false;
          if (response.status === 200) {
            const setResponse = response.data;
            if (setResponse.success) {
              // set twilio chat token in local storage
              Utility.setStorage(configToken.chatTokenKeyName, setResponse.data.chatToken);
              Utility.setStorage(configToken.ecomTokenKey, setResponse.data.ecommToken);
              Utility.setStorage(configToken.zoyloEcomCustId, setResponse.data.ecommId);
              /*pushClevertapProfile(profileData);*/
              /*this.$clevertap('Signup', {
                'First Name': this.firstName,
                'Last Name': this.lastName,
                'Mobile Number': `+91${this.phoneNumber}`,
                'Email': this.emailAddress,
                'Platform': 'Web',
              });
              this.$clevertap('Login', {
                'Mobile Number': `+91${this.phoneNumber}`,
                'Status': true,
                'Platform': 'Web',
              });*/
              const redirectPath = this.$route.query.redirect ? this.$route.query.redirect : '';
              if (!redirectPath) {
                this.$router.push({ path: '/' });
              } else if (redirectPath.indexOf('medicines') === -1) {
                this.$router.push({ path: redirectPath });
              } else {
                window.location.href = `${window.location.origin}${redirectPath}`;
              }
            }
          } else if (response.data) {
            this.errorMessages = displayErrorMessage(response.data.errorCodeList);
          } else {
            this.errorMessages = displayErrorMessage(response.response.data.errorCodeList);
          }
        });
      }
    },
    dontCloseModal(event) {
      if (this.showOTPModal) {
        event.preventDefault();
      }
    },
  },
};
