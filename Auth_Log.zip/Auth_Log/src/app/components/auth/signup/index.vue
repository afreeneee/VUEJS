<template>
    <div class="registeration-container d-flex align-items-center justify-content-center align-content-center">
        
        <loader v-if="isLoading"></loader>
        <div class="registration-content">
            <h5 class=" font-regular text-center"> Create Your Health Account </h5>
            <error-message :errorMessages="errorMessages"> </error-message>
            <form class="floating-label" @submit.prevent="onSubmit" id="registerForm">
                <div class="d-flex align-items-sm-center justify-content-sm-between flex-column flex-sm-row">
                    <div class="form-group required m-0 mr-sm-5 flex-grow-1">
                        <input id="firstName" class="form-control"
                               type="text"
                               v-model="firstName"
                               v-validate="'required|alpha|min:3'"
                               data-vv-name='First Name'
                               placeholder="Enter First Name">
                        <label for="firstName">First Name</label>
                        <span v-show="errors.has('First Name')" class="font12 help-block text-danger">
                            {{ errors.first('First Name') }}</span>
                    </div>
                    <div class="form-group required m-0 flex-grow-1">
                        <input id="lastName" class="form-control"
                               type="text"
                               v-model="lastName"
                               v-validate="'required|alpha|min:3'"
                               data-vv-name='Last Name'
                               placeholder="Enter Last Name">
                        <label for="lastName">Last Name</label>
                        <span v-show="errors.has('Last Name')" class="font12 help-block text-danger">
                            {{ errors.first('Last Name') }}</span>
                    </div>
                </div>
                <div class="form-group required m-0">
                    <input class="form-control" id="phoneNumber"
                           type="text"
                           v-model="phoneNumber"
                           v-validate="'required|numeric|min:10|max:10|mobile'"
                           data-vv-name='Phone Number'
                           maxlength="10"
                           placeholder="Enter Phone Number">
                    <label for="firstName">Mobile No.</label>
                    <span v-show="errors.has('Phone Number')" class="font12 help-block text-danger">
                        {{ errors.first('Phone Number') }}</span>
                </div>
                <div class="form-group required m-0">
                    <input class="form-control" id="emailId"
                           type="text"
                           v-model="emailAddress"
                           v-validate="'required|email'"
                           data-vv-name='Email Address'
                           placeholder="Enter Email Address">
                    <label for="firstName">Email Id</label>
                    <span v-show="errors.has('Email Address')" class="font12 help-block text-danger">
                {{ errors.first('Email Address') }}
        </span>
                </div>
                <div class="form-group required m-0">
                    <input class="form-control" id="password"
                           type="password"
                           v-model="encryptedPassword"
                           v-validate="'required|min:6'"
                           data-vv-name='Password'
                           placeholder="Enter Password">
                    <label for="firstName">Password</label>
                    <span v-show="errors.has('Password')" class="font12 help-block text-danger">
                {{ errors.first('Password') }}
        </span>
                </div>
                <div class="font12 text-center mb-3">By signing up, you agree to our <router-link to='/termsConditions' class="secondary-color font-medium">Terms and Conditions</router-link></div>

                <b-button type="submit" variant="primary" :class="{ disabled: isLoading, 'w-100': true }">Sign Up</b-button>
            </form>
            <div class="font14 grey-text text-center mt-4">Already a member?  <router-link v-bind:to="'/login'" class="secondary-color font-medium">Login</router-link></div>
            <otp-modal ref="OtpModal"
                       :resendAction="otp_resend_action"
                       :phoneNum="phoneNumber"
                       :verifyAction="otp_verify_action"
                       :otpDataId="otpData.id"
                       @otpVerify="autoLogin"
            ></otp-modal>
        </div>
    </div>
</template>
<script src="./signup.js">
</script>
<style src="./signup.css"></style>