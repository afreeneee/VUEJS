const Landing = () => import('./layout/index');


export default [
  {
    path: '/',
    component: Landing,
    name: 'HomeLandingLayout',
  },
];
