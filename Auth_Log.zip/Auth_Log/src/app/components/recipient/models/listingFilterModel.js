export default class ListingFilterModel {
  constructor() {
    return {
      Gender: '',
      amenities: [],
      date: '',
      distanceValue: 20,
      experienceValue: [0, 0],
      gender: [],
      homeVisit: false,
      language: [],
      maxFee: '',
      minFee: '',
      onlineConsultation: false,
      paymentOptions: [],
      session: [],
    };
  }
}
