export default class AddressModel {
  constructor() {
    return {
      addressList: [{
        activeFlag: '',
        addressId: '',
        addressCustomName: '',
        addressTypeCode: '',
        addressTypeId: '',
        defaultFlag: '',
        addressData: {
          addressLineOne: '',
          addressLineTwo: '',
          addressLocality: '',
          cityCode: '',
          cityData: [
            {
              cityName: '',
              languageCode: 'en',
              languageId: '5a1e9fb2dbfa382425a7be3d',
            },
          ],
          cityId: '',
          countryCode: '',
          countryData: [
            {
              countryName: '',
              languageCode: 'en',
              languageId: '5a1e9fb2dbfa382425a7be3d',
            },
          ],
          countryId: '',
          gpsLatitude: '',
          gpsLongitude: '',
          nearbyLandmark: '',
          pinCode: '',
          stateCode: '',
          stateData: [
            {
              languageCode: 'en',
              languageId: '5a1e9fb2dbfa382425a7be3d',
              stateName: '',
            },
          ],
          stateId: '',
        },
      }],
      firstName: '',
      lastName: '',
      middleName: '',
      gender: '',
      bloodGroup: '',
      dateOfBirth: '',
      emailAddress: '',
      phoneNumber: '',
    };
  }
}
