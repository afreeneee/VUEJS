<template>
    <header class="header sticky-top">
      <header-top></header-top>
      <header-main></header-main>
    </header>
</template>

<script>
  import HeaderTop from './header-top';
  import HeaderMain from './header-main';


  export default {
    name: 'Header',
    components: {
      'header-top': HeaderTop,
      'header-main': HeaderMain,
    },
  };
</script>

<style scoped>

</style>
