<template>
  <div class="user-profile ml-3">
    <p class="greet-text" v-if="!toggleSignIn">
      <router-link v-bind:to="'/login'" style="color:#000">
        <a href="javascript:void(0)">Login / Sign Up</a>
      </router-link>
    </p>
    <div class="user-loggedin d-inline-flex align-items-center justify-content-end" :class="{ active : toggleDropdown }"
         v-if="toggleSignIn" @click="openMenu">
      <div>
        <a href="javascript:void(0);" class="d-none d-md-block">Logged in as
          <span class="user white-text font-bold">{{ userData.userName }}</span>
        </a>
      </div>
      <div class="user-image rounded-circle">
        <img :src="userData.imageUrl" class="rounded-circle img-fluid">
      </div>
      <div class="user-dropdown" v-if="toggleDropdown">
        <ul class="profile-list">          
          <li><a href="javascript:void(0);" @click="logout()">Logout</a></li>
        </ul>
      </div>
    </div>
  </div>
</template>

<script>
  import DOC_CONSTANTS from '@/app/utils/resources';

  export default {
    name: 'User-profile',
    data() {
      return {
        toggleSignIn: false,
        toggleDropdown: false,
        userData: {
          userName: '',          
        },
      };
    },
   
    methods: {
      logout() {
        this.$auth.logout();
        this.toggleSignIn = !this.toggleSignIn;
        this.$router.push({ name: 'login' });
      },
      openMenu(evnt) {
        evnt.stopPropagation();
        evnt.target.ownerDocument.addEventListener('click', () => {
          this.toggleDropdown = false;
        });
        this.toggleDropdown = !this.toggleDropdown;
      },
      displayThumNail() {
        this.$store.dispatch('auth/getProfile');
      },
            
    },
  };
</script>

<style lang="scss" scoped>
 
    .user-loggedin {
    position: relative;
    padding: 0 20px 0 0;
    cursor: pointer;
    &:hover{
      a{
        opacity: 1;
      }
    }
    &.active {
      &:after {
        background-position: -258px -44px;;
      }
    }
    &:after {
      content: '';
      position: absolute;
      right: 0px;
      top: 12px;
      border: none;
      //@extend .icon12;
      //@extend .icon;
      margin: 0;
      //background: url(~@/assets/images/zoylo-spritesheet.svg) no-repeat -243px -44px;
    }
    a {
      display: block;
      color: #000;
      opacity: 0.7;
      &:hover {
        opacity: 1;
      }
      span {
        display: block;
      }
    }
    .user-image {
      margin: 0 0 0 10px;
      width: 36px;
      height: 36px;
      background: rgba(#fff, 0.9);
      img{
        height: 100%;
      }
    }
    .user-dropdown {
      z-index: 99999;
      position: absolute;
      top: 50px;
      width: 150px;
      right: 0;
      background: #fff;
      padding: 10px;
      box-shadow: 0 3px 6px 0 rgba(0, 0, 0, 0.16);
      z-index: 50;
      .profile-list {
        li {
          padding: 5px 0;
          border-bottom: 1px solid #eee;
          a {
            color: blue;
            text-align: left;
          }
          &:last-child {
            border: none;
          }
        }
      }
    }
  }
</style>
