<template>
  <div class="header-main">
    <b-navbar toggleable="md" type="light" variant="faded" class="justify-content-between base-padding">
      <div class="d-flex align-items-center order-md-1 mt-5 mt-md-0">
        <router-link v-bind:to="'/'">
          <b-navbar-brand><img src="~@/assets/images/logo.png" alt="zoylo-logo"> </b-navbar-brand>
        </router-link>
      </div>
      <div class="order-md-3 flex-grow-1 text-right mt-5 mt-md-0">
        <user-profile></user-profile>
      </div>      
    </b-navbar>
  </div>
</template>

<script>
  import config from '@/app/utils/index';
  import UserProfile from './user-profile';


  export default {
    name: 'HeaderMain',
    components: {
      'user-profile': UserProfile,
    },
    data() {
      return {
        config,
        
      };
    },
    computed: {
      innerWidth() {
        return window.innerWidth <= 768;
      },
    },
  };
</script>

<style lang="scss" scoped>

  .search-container{
    flex: 1 0 auto;
    position: relative;
    @media only screen and (max-width: 767px) {
      flex: auto;
    }
  }


  .form-inline {
    width: 65%;
    padding: 0;
    background:#fff;
    @media only screen and (max-width: 767px) {
      margin: 20px 0 0;
      width: 100%;
    }
  }


  .header-search {
    flex: 1 0 auto;
    height: 36px;
    @media only screen and (max-width: 767px) {
      width: 50%;
    }
  }
  .search{
    padding: 8px;
    height: 36px;
    width: 36px;

  }
.header-main{
  @media only screen and (max-width: 767px) {
  }
}
.location-input {
    /*width: 100%;*/
    position: relative;
  }

  .location-detect{
    width: 36px;
    height: 36px;
    padding: 7px;
  }

  .location-container{
    position: relative;
    z-index: 2;
    .error-text{
        display: none;
      position: absolute;
      top:50px;
      left:0px;
      color: red;
      border-radius: 4px;
      padding: 10px;
    background: white;
      z-index: 1;
      box-shadow: 0 0px 6px 0 rgba(0, 0, 0, 0.16);
      &:before{
        content: '';
        position: absolute;
        top:-20px;
        left:20px;
        border:10px solid transparent;
        border-bottom-color: white;
      }
    }

    &.error-message{

      .error-text{
        display: block;
      }
      &:before{
        content:'';
        position: absolute;
        top:0;
        left:0;
        right:0;
        bottom:0;
        background: red;
      }
      .location-input::placeholder{
        color: red;
      }
    }

    /*@media only screen and (max-width: 767px) {
      position: absolute !important;
      top: 0px;
      left: 0px;
      margin: 0 0 20px;
      .location-input {
        color: $white;
        min-width: 50px;
        padding: 10px 0;

        &::placeholder {
          color: $white;
        }
      }
      &:before {
        display: none;
      }
    }*/
  }

  .location-popup, .location-container-popup{
    position: fixed;
    left:0;
    right:0;
    top:0;
    bottom:auto;
    min-height: 500px;
    background: white;
    padding: 50px;
    z-index: 50;
    -webkit-box-shadow: 0px 0px 8px 0px rgba(0, 0, 0, 0.25);
    -moz-box-shadow:    0px 0px 8px 0px rgba(0, 0, 0, 0.25);
    box-shadow:         0px 0px 8px 0px rgba(0, 0, 0, 0.25);

    #location-detect{
      width: 100%;
    }
  }


  .location-form{
    padding: 10px;
    background: white;
    border: 1px solid blueGrey;
    border-radius: 4px;
    margin: 30px auto;
    a{
      color: blue;
      flex: 1 0 auto;
      .icon{
        margin: 0 0 0 10px !important;
      }
    }
  }

  .search {
    padding: 10px;
    text-align: center;
    /*margin: 0 0 20px;*/
  }

  .location-container-popup {
    padding: 20px;
    height: 100vh;

    .location-detect {
      width: 200px;
      color: blue;
      padding: 0;
      height: auto;
    }
    .location-container2 {
      padding: 5px 0;
      border-bottom: 2px solid #ccc;
    }
  }
</style>
