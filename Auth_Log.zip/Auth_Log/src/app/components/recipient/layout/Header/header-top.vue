<template>
  <div class="header-top d-none d-lg-flex align-items-center justify-content-between">
    <div class="options-left d-flex align-items-center">
      <router-link :to="{ path: '/', hash: '#downloadApp' }" class="d-flex align-items-center mr-4">Download the App</router-link>
      <router-link :to="{ path: '/', hash: '#userOffers' }" class="d-flex align-items-center">0ffers</router-link>
    </div>
    <div class="d-none d-sm-none d-md-block">
    <div class="primary-options d-flex align-items-center d-none d-sm-none d-md-block">
      <ul class="primary-links d-flex align-items-center">
        <li><router-link :to="{ path: '/', hash: '#listPractice' }">List your Practice </router-link></li>
        <li onclick="$zoho.salesiq.floatwindow.visible('show')"><a> Need Help? </a></li>
        <li><a href="javascript:void(0);" class="d-flex align-items-center "><span class="icon phone-header-icon"></span> 1800 3000 5454 </a></li>
      </ul>
    </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'HeaderTop',
  mounted() {
    if (this.$route.hash) {
      setTimeout(() => this.scrollFix(this.$route.hash), 500);
    }
  },
  methods: {
    scrollFix(hashbang) {
      location.href = hashbang;
    },
  },
};
</script>

<style lang="scss" scoped>

.header-top {
  padding: 10px 15px 0;
}
.primary-links li {
  padding: 0 10px;
  &:last-child{
    padding-right: 0;
  }
}
.icon {
  width: 14px;
  height: 14px;
  margin: 0 5px 0 0;
}
</style>
