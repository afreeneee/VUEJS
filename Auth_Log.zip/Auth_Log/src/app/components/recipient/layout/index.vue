<template>
  <div class="landing ">
    landing Page
  </div>
</template>

<script>
  export default {
    name: 'Landing',
        data() {
      return {
        msg: '',
      };
    },
  };
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style lang="scss" scoped>
p{
  font-family: Verdana;
  font-weight: bold;
}
</style>
