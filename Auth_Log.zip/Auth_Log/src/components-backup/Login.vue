<template>
    <div>
        Login Page
    </div>
</template>

<script>



export default {
  name: 'login',
}
</script>

<style scoped>
    div {
        border: 1px solid red;
        width: 100px;
        height: 100px
    }
</style>