<template>
    <div>
        Contact  Page
    </div>
</template>

<script>



export default {
  name: 'contact',
}
</script>

<style scoped>
    div {
        border: 1px solid red;
        width: 100px;
        height: 100px
    }
</style>