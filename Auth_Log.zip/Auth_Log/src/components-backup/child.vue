<template>
    <div>
        <div class="card m-3">
            <div class="card-body">
                <h5 class="card-title" v-text="thecardtitle"></h5>
                <p class="card-text" v-html="thecardbody"></p>
                <div v-if="parentmessage" class="card-text alert alert-warning" v-html="parentmessage"></div> 
                 <slot name="slotName" ></slot>                
            </div>
        </div>
    </div>
</template>
 
<script>
    export default {
        props: ['parentmessage', 'ok'],
        data() {
            return {
                thecardtitle: 'Child Component!',
                thecardbody: 'I\'m just a child.'
            }
        }
      
    }
</script>
 
<style>
</style>
