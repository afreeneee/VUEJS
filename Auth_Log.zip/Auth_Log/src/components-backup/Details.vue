<template>
	<div class="details">
		<div class="container">
            <div class="row"><router-link to="/">Go Back</router-link></div>
			<div class="row">
				<div class="col-md-12" v-for="(product,index) in products" :key="index"> 
					<div v-if="proId == product.productId">
						<h1>{{product.productTitle}}</h1>
						<img :src="product.image" class="img-fluid">
                        <p>{{product.Description}}</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</template>
<script>
	export default{
		name:'details',
		data(){
			return{
				proId:this.$route.params.Pid,
				title:"Details",
				products:[
				{
				productTitle:"Doctors",
                image       : require('../assets/images/product1.png'),
                Description : "List your practice on Zoylo to reach more patients online and also get Patient Management Software for FREE!",
				productId:1
				},
				{
				productTitle:"Labs",
                image       : require('../assets/images/product2.png'),
                Description : "List your diagnostic lab on Zoylo to reach more patients looking for your services online.",
				productId:2
				},
				{
				productTitle:"Hospital",
                image       : require('../assets/images/product3.png'),
                Description : "List your diagnostic lab on Zoylo to reach more patients looking for your services online.",
				productId:3
				},
				{
				productTitle:"Home Health Care",
                image       : require('../assets/images/product4.png'),
                Description : "List your diagnostic lab on Zoylo to reach more patients looking for your services online.",
				productId:4
				},
				{
				productTitle:"Clinics",
                image       : require('../assets/images/product5.png'),
                Description : "List your diagnostic lab on Zoylo to reach more patients looking for your services online.",
				productId:5
				},
				{
				productTitle:"Others",
                image       : require('../assets/images/product6.png'),
                Description : "List your diagnostic lab on Zoylo to reach more patients looking for your services online.",
				productId:6
				}
				]
				 
			}
		}
		
	}
</script>