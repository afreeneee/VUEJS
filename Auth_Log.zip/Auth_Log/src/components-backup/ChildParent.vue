
1<template>
    <div class="services">
        <h1>{{title}}</h1>
        <div class="card m-2">
            <div class="card-body">
                <h5 class="card-title" v-text="thecardtitle"></h5>
                <button @click="sendMessage" class="btn btn-info">Send Child A Message</button>
                <parent :parentmessage="parentmessage" :ok="ok" @finished="finished"></parent>
            </div>
        </div>
    </div>
</template>
 
<script>
    import parent from './parent.vue';
 
    export default {
        components: {parent},
 
        data() {
            return {
                title: 'Child to Parent passing Data',
                thecardtitle: 'Parent Component!',
                parentmessage: ''
            }
        },
 
        methods: {
            sendMessage() {
                this.parentmessage = '<b>Message From Parent:</b> Do Your Homework'
            },
 
            finished() {
                this.parentmessage = ''
            },
 
            ok() {
                this.finished()
            }
        }
    }
</script>
 
<style>
</style>
