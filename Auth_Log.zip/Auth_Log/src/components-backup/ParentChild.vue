<template>
	<div class="services">
		<h1>{{title}}</h1>
		   <div class="card m-2">
            <div class="card-body">
                <h5 class="card-title" v-text="thecardtitle"></h5>
                <button @click="sendMessage" class="btn btn-info">Send Child A Message</button>
                <childName :parentmessage="parentmessage"></childName>
				 <childName>
					  <template slot="slotName">
						  <p>I'm injected content from the parent!</p>
      <p>I can still bind to data in the parent's scope, like this! </p>
   </template>
      
    </childName>
            </div>
        </div>
	</div>
</template>
<script>
    import childName from './child.vue'; 
    export default {
        components: {childName},
 
        data() {
            return {
				title:'Parent to Child passing data',
                thecardtitle: 'Parent Component!',
                parentmessage: ''
            }
        },
        methods: {
            sendMessage() {
                alert("hello");
                this.parentmessage = '<b>Message From Parent:</b> Do Your Homework'
			}
			
        }
    }
</script>
<style>
</style>