import Vue from 'vue/dist/vue.js'
import Router from 'vue-router';
import { routes } from '../app/index';

Vue.use(Router);

export default new Router({
  mode: 'history',
  scrollBehavior(to) {
    if (to.hash) {
      return { selector: to.hash };
    }
    return { x: 0, y: 0 };
  },
  routes,
});

/*import Vue from 'vue/dist/vue.js'
import VueRouter from 'vue-router'
import home from '@/components/Home'
import login from '@/components/Login'
import services from '@/components/Services'
import contact from '@/components/Contact'
import details from '@/components/Details'
import parentchild from '@/components/ParentChild'
import childparent from '@/components/ChildParent'

Vue.use(VueRouter)

export default new VueRouter({
  routes: [
    {
      path: '/',
      name: 'home',
      component: home
    },
    {
      path: '/login',
      name: 'login',
      component: login
    },
    {
      path: '/services',
      name: 'services',
      component: services
    },
    {
      path: '/contact',
      name: 'contact',
      component: contact
    },
    {
      path: '/details/:Pid',
      name: 'details',
      component: details
    },
    {
      path: '/parentchild',
      name: 'parentchild',
      component: parentchild
    },
    {
      path: '/childparent',
      name: 'childparent',
      component: childparent
    },
  ]
})*/
