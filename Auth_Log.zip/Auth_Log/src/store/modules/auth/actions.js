import fetch from '@/app/services/httpService';
import constant from '@/app/utils/index';



const registerUser = ((context, details) =>
  (fetch.postApi(constant.api.GATEWAY.REGISTER_URL, details)));

const login = async (context, loginDetails) => {//eslint-disable-line
  const requestData = {
    username: loginDetails.phone,
    password: loginDetails.password,
    roleCategory: 'RECIPIENT',
  };
  alert(this.requestData);
  const response = await fetch.postApi('https://uat-gateway.zoylo.com/zoylogateway-0.0.1-SNAPSHOT/api/authenticate', requestData);
  return response;
};


export default {
  registerUser,
  login,
 };
