import { getField } from 'vuex-map-fields';

const profileData = state => state.editProfile;

export default {
  getField,
  profileData,
};
