import actions from './actions'


const state = {
  loginDetails: {
    username: '',
    password: '',
    roleCategory: 'RECIPIENT',
  },
};

export default {
  namespaced: true,
  state,
  actions,
};