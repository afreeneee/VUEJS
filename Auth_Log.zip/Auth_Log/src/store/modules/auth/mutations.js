import { updateField } from 'vuex-map-fields';

const GET_USERDETAILS = (state, response) => {
  // eslint-disable-next-line no-param-reassign
  state.editProfile = response.data;
};

export default {
  updateField,
  GET_USERDETAILS,
};
